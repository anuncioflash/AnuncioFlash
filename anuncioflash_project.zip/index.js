function mostrarMensaje() {
    alert('Funcionalidad en desarrollo. ¡Pronto podrás publicar anuncios!');
}